document.addEventListener('DOMContentLoaded', function () {
    fetch('https://jsonplaceholder.typicode.com/posts/1')
        .then(response => response.json())
        .then(data => {
            const postContainer = document.createElement('div');
            postContainer.innerHTML = `<h3>${data.title}</h3><p>${data.body}</p>`;
            document.body.appendChild(postContainer);
        });

    const form = document.getElementById('contactForm');
    const feedback = document.getElementById('formFeedback');

    form.addEventListener('submit', function (event) {
        event.preventDefault();
        const name = form.name.value.trim();
        const email = form.email.value.trim();

        if (!name || !email) {
            feedback.textContent = 'Please fill out all fields.';
            feedback.style.color = 'red';
        } else {
            feedback.textContent = 'Form submitted successfully!';
            feedback.style.color = 'green';
        }
    });
});

function changeBackgroundColor() {
    document.body.style.backgroundColor = 'lightblue';
}
